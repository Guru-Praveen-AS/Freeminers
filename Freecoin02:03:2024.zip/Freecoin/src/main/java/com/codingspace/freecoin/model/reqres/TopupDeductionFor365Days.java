package com.codingspace.freecoin.model.reqres;

import com.codingspace.freecoin.model.TopupRequest;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@Setter
@Getter
@Document(collection = "TopupDeductionFor365Days")
public class TopupDeductionFor365Days {
    @Id
    private String userId;
    private List<TopupRequest> deductedTopupRequests;
    private double deductedAmount;
}
