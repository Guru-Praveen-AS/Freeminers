package com.codingspace.freecoin.model;


import java.util.Date;

public class OldPasswordLogs {
    private String oldPassword;
    private Date changedAt ;
}
