package com.codingspace.freecoin.model.reqres;

import lombok.Getter;

@Getter
public class AuthValidateReq {
    String refId;
    String password;
}
